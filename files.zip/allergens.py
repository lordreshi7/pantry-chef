"""Deterministic allergen checks.

The LLM tags allergens during extraction, but we never rely on that alone.
These keyword rules run on top as a safety net, and a recipe is excluded if
EITHER source flags an allergen. False positives (excluding a safe recipe)
are acceptable; false negatives are not.

This list is not exhaustive and can't see inside packaged products, so the UI
should still tell users to check labels.
"""
from __future__ import annotations

from .schemas import Allergen, Recipe, UserProfile

_WHEAT = [
    "wheat", "flour", "bread", "breadcrumb", "panko", "pasta", "spaghetti", "macaroni",
    "noodle", "couscous", "semolina", "bulgur", "farro", "spelt", "seitan", "maida",
    "atta", "sooji", "rava", "tortilla", "pita", "naan", "cracker", "soy sauce",
]

ALLERGEN_KEYWORDS: dict[Allergen, list[str]] = {
    Allergen.MILK: ["milk", "butter", "cheese", "cream", "yogurt", "yoghurt", "ghee",
                    "paneer", "whey", "curd", "khoa", "casein", "ricotta", "mozzarella"],
    Allergen.EGGS: ["egg", "mayonnaise", "mayo", "meringue", "aioli"],
    Allergen.FISH: ["fish", "salmon", "tuna", "cod", "anchov", "sardine", "mackerel",
                    "tilapia", "trout", "halibut", "worcestershire"],
    Allergen.SHELLFISH: ["shrimp", "prawn", "crab", "lobster", "crayfish", "langoustine"],
    Allergen.MOLLUSCS: ["clam", "mussel", "oyster", "scallop", "squid", "octopus", "calamari"],
    Allergen.TREE_NUTS: ["almond", "cashew", "walnut", "pecan", "pistachio", "hazelnut",
                         "macadamia", "pine nut", "brazil nut", "praline", "marzipan", "pesto"],
    Allergen.PEANUTS: ["peanut", "groundnut"],
    Allergen.WHEAT: _WHEAT,
    Allergen.GLUTEN: _WHEAT + ["barley", "rye", "malt", "beer"],
    Allergen.SOY: ["soy", "tofu", "tempeh", "edamame", "miso"],
    Allergen.SESAME: ["sesame", "tahini", "gingelly"],
    Allergen.MUSTARD: ["mustard"],
}

# Phrases removed before keyword matching, to avoid known false matches.
_WHEAT_FREE = [
    "buckwheat", "rice flour", "almond flour", "coconut flour", "chickpea flour",
    "gram flour", "corn flour", "cornflour", "tapioca flour", "potato flour",
    "rice noodle", "corn tortilla",
]
EXCLUSIONS: dict[Allergen, list[str]] = {
    Allergen.MILK: ["coconut milk", "almond milk", "oat milk", "soy milk", "rice milk",
                    "coconut cream", "cream of tartar", "peanut butter", "almond butter",
                    "cocoa butter", "apple butter", "butternut"],
    Allergen.EGGS: ["eggplant"],
    Allergen.FISH: ["shellfish"],
    Allergen.MOLLUSCS: ["oyster mushroom"],
    Allergen.WHEAT: _WHEAT_FREE,
    Allergen.GLUTEN: _WHEAT_FREE,
}


def detect_allergens(text: str) -> set[Allergen]:
    """Allergens suggested by an ingredient name or line, via keyword rules."""
    text = text.lower()
    found: set[Allergen] = set()
    for allergen, keywords in ALLERGEN_KEYWORDS.items():
        cleaned = text
        for phrase in EXCLUSIONS.get(allergen, []):
            cleaned = cleaned.replace(phrase, " ")
        if any(kw in cleaned for kw in keywords):
            found.add(allergen)
    return found


def recipe_allergens(recipe: Recipe) -> set[Allergen]:
    """Union of LLM tags and keyword detection across all ingredients."""
    found: set[Allergen] = set()
    for ing in recipe.ingredients:
        found |= set(ing.allergens)
        found |= detect_allergens(ing.name)
        found |= detect_allergens(ing.raw_text)
    return found


def safety_violations(recipe: Recipe, profile: UserProfile) -> list[str]:
    """Reasons this recipe is unsafe for the user. Empty list means safe."""
    reasons: list[str] = []
    for ing in recipe.ingredients:
        hits = (set(ing.allergens) | detect_allergens(ing.name) | detect_allergens(ing.raw_text))
        for allergen in hits & set(profile.allergies or []):
            reasons.append(f"'{ing.raw_text}' contains {allergen.value}")
        for avoid in profile.avoid_ingredients:
            if avoid.lower() in ing.name or avoid.lower() in ing.raw_text.lower():
                reasons.append(f"'{ing.raw_text}' contains {avoid}")
    return reasons
